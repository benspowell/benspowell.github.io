BEN POWELL'S RESUME TEMPLATE :)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

FONTS: 
----------------------------------------------------------------------------
-All the fonts you need are in the fonts folder. You need to install them.

-How to install fonts: https://www.fontspring.com/support/how-do-i-install-fonts-on-my-windows-pc

-What fonts are used where:
	-SCALA: used only for name at top of page
	-GOTHAM: used for section headers
	-SCALA SANS: everything else. Bold for content headings. 
	 Regular for main content. Italic when it feels right.

TIPS:
----------------------------------------------------------------------------
-If you need to make the resume a little bit shorter or longer,
just select everything except the header and make small adjustments
to the line spacing options until it's the right length 

-The lines underneath the headers need to be moved around manually

-I used a bullet point character instead of Word's bullet points.
To put a bullet somewhere, just copy and paste the character from
somewhere else on the page.

-If you submit it to an online application or email it, always save 
the resume as Your_Name.pdf . Recruiters will have a bunch of resume.pdf's 
on their computer, and it's good for yours to be easily recognizable

